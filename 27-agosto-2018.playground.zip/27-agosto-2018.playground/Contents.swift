
//: Playground - noun: a place where people can play

import UIKit

struct Alumno{
    var numeroCuenta: String
    var nombre: String
    var edad: Int
    
    func estudiar(){
        print("Alumno estudiando")
    }
    
    func leer(){
        print("Alumno leyendo")
    }
    
    init(nombre: String, numeroCuenta: String, edad: Int){
        self.nombre = nombre
        self.numeroCuenta = numeroCuenta
        self.edad = edad
    }
    
    init(edad: Int) {
        self.nombre = "nobody"
        self.edad = edad
        self.numeroCuenta = "000000000"
    }
    
    mutating func modicaEdad(){
        self.edad = self.edad + 1
    }
}

var juan = Alumno(nombre: "Juan", numeroCuenta: "312068415", edad:22)
var pedro = juan
juan.edad = 23
print(juan)
juan.leer()
juan.modicaEdad()
print(juan)

