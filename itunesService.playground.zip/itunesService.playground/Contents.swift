//: Playground - noun: a place where people can play

import UIKit
import PlaygroundSupport
//JSON: java script object notation

/*let url = URL(string: "https://itunes.apple.com/search?term='metallica'")!

 /*singletone*/
let task = URLSession.shared.dataTask(with: url){ (data, response,error) in
    if let datos = data, let cadena = String(data: datos, encoding: .utf8){
        print(cadena)
    }
}

task.resume() */

let url = URL(string: "https://itunes.apple.com/search?term='metallica'")!

let jsonDecode = JSONDecoder()

struct Resultados: Codable{
    var resultCount: Int
    var results: [Track]
}
struct Track: Codable{
    var trackName: String
    var trackPrice: Double
}

let task = URLSession.shared.dataTask(with: url){ (data, response,error) in
    if let datos = data, let resultado = try? jsonDecode.decode(Resultados.self,from: datos){
        resultado.results.forEach({(track) in
            print(track.trackName, track.trackPrice)
        })
    }
}

task.resume()

PlaygroundPage.current.needsIndefiniteExecution = true
